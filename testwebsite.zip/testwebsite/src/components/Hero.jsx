import React from 'react';
import './Hero.css';

const Hero = () => {
  return (
    <section className="hero" id="home">
      <div className="hero-content">
        <h1>Hello, I'm <span className="highlight">Your Name</span></h1>
        <h2>Frontend Developer</h2>
        <p>I build beautiful and performant web applications. Welcome to my portfolio!</p>
        <a href="#projects" className="hero-btn">View My Work</a>
      </div>
      <div className="hero-image">
        {/* Placeholder for profile image or illustration */}
        <div className="profile-placeholder"></div>
      </div>
    </section>
  );
};

export default Hero;
