import React from 'react';
import './Projects.css';

const Projects = () => {
  return (
    <section className="projects" id="projects">
      <h2>Projects</h2>
      <div className="projects-list">
        <div className="project-card">
          <h3>Portfolio Website</h3>
          <p>A modern, responsive portfolio website built with React and Vite.</p>
          <a href="#" className="project-link">View Project</a>
        </div>
        <div className="project-card">
          <h3>Task Manager App</h3>
          <p>Task management app with drag-and-drop and real-time updates.</p>
          <a href="#" className="project-link">View Project</a>
        </div>
        <div className="project-card">
          <h3>Blog Platform</h3>
          <p>Full-featured blog platform with markdown support and comments.</p>
          <a href="#" className="project-link">View Project</a>
        </div>
      </div>
    </section>
  );
};

export default Projects;
