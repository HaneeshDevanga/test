import React from 'react';
import './About.css';

const About = () => {
  return (
    <section className="about" id="about">
      <h2>About Me</h2>
      <p>
        I am a passionate frontend developer with experience building modern, responsive web applications using React.js and other cutting-edge technologies. I love turning ideas into beautiful, user-friendly products.
      </p>
      <ul className="about-skills">
        <li>React.js</li>
        <li>JavaScript (ES6+)</li>
        <li>HTML & CSS</li>
        <li>Vite</li>
        <li>UI/UX Design</li>
      </ul>
    </section>
  );
};

export default About;
